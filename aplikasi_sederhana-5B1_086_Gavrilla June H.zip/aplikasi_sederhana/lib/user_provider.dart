import 'package:flutter/material.dart';

class UserProvider with ChangeNotifier {
  String _username = "";

  String get username => _username;
  bool get isLoggedIn => _username.isNotEmpty;

  void login(String name) {
    _username = name;
    notifyListeners();
  }

  void logout() {
    _username = "";
    notifyListeners();
  }
}