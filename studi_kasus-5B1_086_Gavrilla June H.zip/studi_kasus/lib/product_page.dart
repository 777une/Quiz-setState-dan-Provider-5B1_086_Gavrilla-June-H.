import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'cart_provider.dart';

class ProductPage extends StatelessWidget {
  final List<String> products = [
    "Sepatu",
    "Tas",
    "Kemeja",
    "Celana",
    "Topi",
  ];

  @override
  Widget build(BuildContext context) {
    final cart = Provider.of<CartProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text("Toko Online"),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 20),
            child: Center(
              child: Text(
                "Cart: ${cart.jumlah}",
                style: TextStyle(fontSize: 18),
              ),
            ),
          )
        ],
      ),
      body: ListView.builder(
        itemCount: products.length,
        itemBuilder: (context, index) {
          return ListTile(
            leading: Icon(Icons.shopping_bag),
            title: Text(products[index]),
            trailing: ElevatedButton(
              onPressed: () {
                cart.tambah();
              },
              child: Text("Tambah ke Cart"),
            ),
          );
        },
      ),
    );
  }
}