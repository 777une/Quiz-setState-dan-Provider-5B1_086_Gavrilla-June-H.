import 'package:flutter/material.dart';

class CartProvider with ChangeNotifier {
  int _jumlah = 0;

  int get jumlah => _jumlah;

  void tambah() {
    _jumlah++;
    notifyListeners();
  }

  void reset() {
    _jumlah = 0;
    notifyListeners();
  }
}