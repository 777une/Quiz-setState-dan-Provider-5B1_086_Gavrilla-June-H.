package com.example.studi_kasus

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
