import 'package:flutter/material.dart';

void main() {
  runApp(MaterialApp(
    home: KalkulatorSetState(),
    debugShowCheckedModeBanner: false,
  ));
}

class KalkulatorSetState extends StatefulWidget {
  @override
  _KalkulatorSetStateState createState() => _KalkulatorSetStateState();
}

class _KalkulatorSetStateState extends State<KalkulatorSetState> {
  TextEditingController angka1Controller = TextEditingController();
  TextEditingController angka2Controller = TextEditingController();

  double hasil = 0;

  void hitung(String operasi) {
    double a = double.tryParse(angka1Controller.text) ?? 0;
    double b = double.tryParse(angka2Controller.text) ?? 0;

    setState(() {
      if (operasi == "tambah") {
        hasil = a + b;
      } else if (operasi == "kurang") {
        hasil = a - b;
      } else if (operasi == "kali") {
        hasil = a * b;
      } else if (operasi == "bagi") {
        hasil = b != 0 ? a / b : 0;
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Kalkulator Sederhana (setState)"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            TextField(
              controller: angka1Controller,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: "Angka Pertama",
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 15),
            TextField(
              controller: angka2Controller,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: "Angka Kedua",
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 20),

            // Tombol operasi
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                ElevatedButton(
                    onPressed: () => hitung("tambah"), child: Text("+")),
                ElevatedButton(
                    onPressed: () => hitung("kurang"), child: Text("-")),
                ElevatedButton(
                    onPressed: () => hitung("kali"), child: Text("×")),
                ElevatedButton(
                    onPressed: () => hitung("bagi"), child: Text("÷")),
              ],
            ),

            SizedBox(height: 30),

            Text(
              "Hasil: $hasil",
              style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
            )
          ],
        ),
      ),
    );
  }
}