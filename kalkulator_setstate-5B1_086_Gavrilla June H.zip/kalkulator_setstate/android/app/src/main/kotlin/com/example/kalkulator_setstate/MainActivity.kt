package com.example.kalkulator_setstate

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
